import numpy as np
import torch
import random
import cv2
from config import system_configs
from torch_geometric.data import Data,DataLoader
def kp_track(db, k_ind, data_aug=True, debug=False):
    batch_size = system_configs.batch_size
    images = []
    positions = np.zeros((batch_size,5,4), dtype=np.float32)
    last_positions= np.zeros((batch_size,2), dtype=np.float32)
    space = np.zeros((batch_size,6,16), dtype=np.float32)
    data_list = []
    labels = np.zeros((batch_size, ), dtype=np.float32)
    db_size = len(db.db_inds)

    for b_ind in range(batch_size):
        if k_ind==0:
            db.shuffle_inds()
        db_ind = db.db_inds[k_ind]
        k_ind = (k_ind + 1) % db_size

        pimg,labels[b_ind] = db.read_data(db_ind)
        pimgs,plist,pgraph = pimg["img"],pimg["plist"],pimg["graph"]
        plist = np.array(plist)
        plist[:-1,0:2] += np.random.rand(6,2)*2-1
        # plist[:-1,2:4] += np.random.rand(6,2)*1-0.5
        plist[:-1,2:4] += plist[:-1,0:2]
        # temp_c = plist[:-2,-2:]-plist[1:-1,-2:]
        # temp_wh = plist[:-2,2:4]-plist[1:-1,2:4]
        # positions[b_ind]=np.hstack([temp_c,temp_wh])
        positions[b_ind]=plist[:-2,0:4]-plist[1:-1,0:4]
        last_positions[b_ind]=plist[-3,-2:]-plist[-1,-2:]
        temp_graph = []
        for i,g in enumerate(pgraph):
            # temp_c = g[:,-2:]
            temp_c = g[1:,-2:]-g[0,-2:]
            temp_wh = g[1:,2:4]
            temp = np.hstack([temp_c,temp_wh]).reshape(-1) + np.random.rand(16)*2-1
            space[b_ind,i]= temp/10.0
            # temp = torch.from_numpy(temp.astype(np.float32))
            # b,c = temp.size()
            # edge_index = torch.stack([torch.zeros(b,dtype=torch.long),torch.arange(b,dtype=torch.long)])
            # edge_index = torch.cat([edge_index,edge_index[[1,0],1:]],dim=1)
            # # x = self.graph()
            # data_list.append(Data(x=temp,edge_index=edge_index))
            # temp_graph.append()
            # edge_index = torch.stack([torch.zeros(b,dtype=torch.long),torch.arange(b,dtype=torch.long)]).cuda()
        # graphs.append(temp_graph)
        # temp_imgs = []
        # for img in pimgs:
        #     img = cv2.resize(img,(16,16))
        #     img = img.transpose([2, 0, 1]).astype(np.float32)/255.0
        #     img = torch.from_numpy(img[np.newaxis,:])
        #     temp_imgs.append(img)
        # images.append(temp_imgs)
        a = 1
    # images      = torch.from_numpy(images)
    positions = torch.from_numpy(positions)
    last_positions = torch.from_numpy(last_positions/10.0)
    labels = torch.from_numpy(labels)
    space = torch.from_numpy(space)

    return {
        "xs": [images,positions,space],
        "ys": [labels,last_positions]
    },k_ind

def sample_data(db, k_ind, data_aug=True, debug=False):
    return globals()[system_configs.sampling_function](db, k_ind, data_aug, debug)