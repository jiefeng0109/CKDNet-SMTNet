
from db.remote import REMOTE
datasets = {
    "REMOTE" : REMOTE,

}
