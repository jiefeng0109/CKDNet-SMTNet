from motmetrics.apps.evaluateTracking import *
#python eval.py ./gt ./s_res j.txt --iou 0.3 --solver lap
if __name__ == '__main__':
    main()